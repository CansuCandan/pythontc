from django.http import HttpResponse


def anasayfa(requests):
    return HttpResponse("MErhaba")
